#include "db.h"
#include <string.h>

/* Inicializa banco */
int db_init(void) {
    FILE *f = fopen(DB_FILE, "ab+");
    if (!f) return 0;
    fclose(f);
    return 1;
}

/* Inserir ocorrência */
int db_create(const Ocorrencia *o) {
    FILE *f = fopen(DB_FILE, "ab");
    if (!f) return 0;

    Ocorrencia temp = *o;
    temp.ativo = 1;

    fwrite(&temp, sizeof(Ocorrencia), 1, f);
    fclose(f);
    return 1;
}

/* Buscar por ID */
int db_read(int id, Ocorrencia *out) {
    FILE *f = fopen(DB_FILE, "rb");
    if (!f) return 0;

    Ocorrencia temp;
    while (fread(&temp, sizeof(Ocorrencia), 1, f)) {
        if (temp.id_ocorrencia == id && temp.ativo) {
            *out = temp;
            fclose(f);
            return 1;
        }
    }
    fclose(f);
    return 0;
}

/* Atualizar ocorrência */
int db_update(int id, const Ocorrencia *novo) {
    FILE *f = fopen(DB_FILE, "rb+");
    if (!f) return 0;

    Ocorrencia temp;
    while (fread(&temp, sizeof(Ocorrencia), 1, f)) {
        if (temp.id_ocorrencia == id && temp.ativo) {
            fseek(f, -(long)sizeof(Ocorrencia), SEEK_CUR);

            Ocorrencia atualizado = *novo;
            atualizado.id_ocorrencia = id;
            atualizado.ativo = 1;

            fwrite(&atualizado, sizeof(Ocorrencia), 1, f);
            fclose(f);
            return 1;
        }
    }
    fclose(f);
    return 0;
}

/* Exclusão lógica */
int db_delete(int id) {
    FILE *f = fopen(DB_FILE, "rb+");
    if (!f) return 0;

    Ocorrencia temp;
    while (fread(&temp, sizeof(Ocorrencia), 1, f)) {
        if (temp.id_ocorrencia == id && temp.ativo) {
            temp.ativo = 0;
            fseek(f, -(long)sizeof(Ocorrencia), SEEK_CUR);
            fwrite(&temp, sizeof(Ocorrencia), 1, f);
            fclose(f);
            return 1;
        }
    }
    fclose(f);
    return 0;
}

/* Lista simples */
void db_list_all(void) {
    FILE *f = fopen(DB_FILE, "rb");
    if (!f) {
        printf("Erro ao abrir banco\n");
        return;
    }

    Ocorrencia o;
    printf("\n=== OCORRÊNCIAS ===\n");
    while (fread(&o, sizeof(Ocorrencia), 1, f)) {
        if (o.ativo) {
            printf(
                "ID:%d | Data:%s | Crime:%s | Status:%s | Cela:%d\n",
                o.id_ocorrencia,
                o.data_entrada,
                o.tipo_crime,
                o.status == 0 ? "Preso" : "Solto",
                o.cela
            );
        }
    }
    fclose(f);
}

/* Ordenação por ID */
void db_list_sorted_by_id(void) {
    FILE *f = fopen(DB_FILE, "rb");
    if (!f) return;

    Ocorrencia lista[MAX_OCORRENCIAS];
    int count = 0, i, j;

    while (fread(&lista[count], sizeof(Ocorrencia), 1, f) && count < MAX_OCORRENCIAS) {
        if (lista[count].ativo)
            count++;
    }
    fclose(f);

    for (i = 0; i < count - 1; i++) {
        for (j = 0; j < count - i - 1; j++) {
            if (lista[j].id_ocorrencia > lista[j + 1].id_ocorrencia) {
                Ocorrencia aux = lista[j];
                lista[j] = lista[j + 1];
                lista[j + 1] = aux;
            }
        }
    }

    printf("\n=== ORDENADO POR ID ===\n");
    for (i = 0; i < count; i++) {
        printf("ID:%d Data:%s Crime:%s Cela:%d\n",
               lista[i].id_ocorrencia,
               lista[i].data_entrada,
               lista[i].tipo_crime,
               lista[i].cela);
    }
}

/* Ordenação por data */
void db_list_sorted_by_date(void) {
    FILE *f = fopen(DB_FILE, "rb");
    if (!f) return;

    Ocorrencia lista[MAX_OCORRENCIAS];
    int count = 0, i, j;

    while (fread(&lista[count], sizeof(Ocorrencia), 1, f) && count < MAX_OCORRENCIAS) {
        if (lista[count].ativo)
            count++;
    }
    fclose(f);

    for (i = 0; i < count - 1; i++) {
        for (j = 0; j < count - i - 1; j++) {
            if (strcmp(lista[j].data_entrada, lista[j + 1].data_entrada) > 0) {
                Ocorrencia aux = lista[j];
                lista[j] = lista[j + 1];
                lista[j + 1] = aux;
            }
        }
    }

    printf("\n=== ORDENADO POR DATA ===\n");
    for (i = 0; i < count; i++) {
        printf("ID:%d Data:%s Crime:%s Cela:%d\n",
               lista[i].id_ocorrencia,
               lista[i].data_entrada,
               lista[i].tipo_crime,
               lista[i].cela);
    }
}
