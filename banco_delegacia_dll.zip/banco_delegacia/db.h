#ifndef DB_H
#define DB_H

#include <stdio.h>

#define DB_FILE "delegacia.bin"
#define MAX_OCORRENCIAS 100

typedef struct {
    int id_ocorrencia;
    int id_suspeito;
    char data_entrada[11];   // YYYY-MM-DD
    char tipo_crime[15];     // Furto / Roubo
    int status;              // 0 Preso | 1 Solto
    int cela;
    int ativo;
} Ocorrencia;

/* Banco */
int db_init(void);
int db_create(const Ocorrencia *o);
int db_read(int id, Ocorrencia *out);
int db_update(int id, const Ocorrencia *novo);
int db_delete(int id);

/* Listagens */
void db_list_all(void);
void db_list_sorted_by_id(void);
void db_list_sorted_by_date(void);

#endif
