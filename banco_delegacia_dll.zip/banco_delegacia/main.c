#include "db.h"

int main(void) {
    db_init();

    Ocorrencia o1 = {3, 201, "2026-02-09", "Furto", 0, 12};
    Ocorrencia o2 = {1, 202, "2026-02-07", "Roubo", 0, 8};
    Ocorrencia o3 = {2, 203, "2026-02-08", "Furto", 1, 0};

    db_create(&o1);
    db_create(&o2);
    db_create(&o3);

    db_list_all();
    db_list_sorted_by_id();
    db_list_sorted_by_date();

    return 0;
}
